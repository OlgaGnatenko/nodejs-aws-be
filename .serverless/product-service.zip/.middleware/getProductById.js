'use strict';
    
const src_middleware_logRequest = require('../src/middleware/logRequest');
const src_lambdas_getProductById = require('../src/lambdas/getProductById');

module.exports.handler = async (event, context) => {
  let end = false;
  context.end = () => end = true;

  const wrappedHandler = handler => prev => {
    if (end) return prev;
    context.prev = prev;
    return handler(event, context);
  };

  return Promise.resolve()
    .then(wrappedHandler(src_middleware_logRequest.logRequest.bind(src_middleware_logRequest)))
    .then(wrappedHandler(src_lambdas_getProductById.getProductById.bind(src_lambdas_getProductById)));
};