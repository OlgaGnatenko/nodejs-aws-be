const processString = (str) => str.trim();

module.exports = {
  processString,
};
